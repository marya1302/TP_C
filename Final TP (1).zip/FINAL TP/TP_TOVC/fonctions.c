#include <stdio.h>
#include <stdlib.h>
#include "fonctions.h"
#include <string.h>

/***************************************************************************************************************/
//------------------------Implementation des fonctions----------------------------------------------------------
/****************************************************************************************************************/
/***************************Fonctions utilisables****************************************************************/
/*-----------------------------Fonction ecrire_ch-------------------------------------------*/
//Role:ecrit la chaine ch qui est de longueur n dans le fichier f dans la position i,j
/********************************************************************************************/
void ecrire_ch(TOVC *f,int n,int *i,int *j,char ch[taille_bloc],int *cost_lec,int *cost_ecr)
{
    Tbloc buf;
    int k=0;
    int cpt_lec=0,cpt_ecr=0;
    lireDir(f,(*i),&buf); //On lit le buffer ou on va ecrire
    cpt_lec++;
    for (k=0;k<n;k++)
    {
        buf.tab[(*j)]=ch[k];  //On recopie la chaine dans le buffer
        (*j)++;


        if ((*j)>=taille_bloc)
        {
            ecrireDir(f,(*i),&buf); //On ecrit le buffer et on saute a un prochain bloc
           cpt_ecr++;
            strcpy(buf.tab,"");     //On r�initialise le buffer
            (*i)=alloc_bloc(f);
            (*j)=0;

        }
    }
    //On a termin� de recopier maintenant on verifie si le dernier buffer n'a pas �t� remplis completement (j!=0) alors on l'ecrit
    if ((*j)!=0)
    {buf.tab[(*j)]='\0';
    ecrireDir(f,(*i),&buf);
    cpt_ecr++;
    }
   (*cost_ecr)=cpt_ecr;
   (*cost_lec)=cpt_lec;


}
/*********************************************************************************************************/
/*---------------------------Fonction Turn to string-----------------------------------------------------*/
//Role:Convertit l'entier n en une chaine de longeur "longueur"
/*********************************************************************************************************/
void turn_to_string(char chaine[], int n, int longueur)
// Convertir l'entier "n" en une chaine de longueur "longueur"
{
    int k;

    for(k=longueur-1;k>=0;k--)
        {
        chaine[k]=(n%10)+'0';
        n=n/10;
        }

    chaine[longueur]='\0';
}
/*********************************************************************************************************/
/*---------------------------Fonction Prepare article-----------------------------------------------------*/
//Role:Prepare l'article pour l'ins�rer en concatenant le taille , le champ effac�e et la donn�e
/*********************************************************************************************************/
void prepare_article(char chaine[],char donne[taille_bloc])
{    int l=strlen(donne);  //On obtient la taille de la donn�e
     char tai[3];
     turn_to_string(tai,l,3);
    strcpy(chaine,tai);
    strcat(chaine,"0"); //On concat�ne le champ effac�e qui est a 0
    strcat(chaine,donne); //On rajoute la donn�e
    strcat(chaine,"\0");   //On indique la fin de la chaine

}
/*********************************************************************************************/
/*--------------------Fonction recuperer-----------------------------------------*/
//Role:r�cup�re du fichier f a partir de la position i,j une chaine de longueur n
/***************************************************************************/
char *recuperer(TOVC *f,int n,int *i,int *j,int *cost)
{   Tbloc buf;
    char ch[n];
    int cpt=0;
    lireDir(f,*i,&buf);
    cpt++;
    int k=0;
    for (k=0;k<n;k++)
    {
       ch[k]=buf.tab[(*j)];  //On recopie les caracteres du buffer dans la chaine ch
       (*j)++;
       if ((*j)>=taille_bloc)
       {
           (*i)++;              //On saute a un nouveau bloc
           lireDir(f,*i,&buf);
            cpt++;
           (*j)=0;
       }
    }
    ch[n]='\0'; //Pour indiquer que la chaine s'arrete ici
    (*cost)=cpt;
    return(ch);
}
/***************************************************************************/
//***************************************************************************
/*----------------- Fonction Affiche bloc---------------------------------*/
//Role: Affiche un bloc donn� du ficchier f
/**************************************************************************/
void affiche_bloc(TOVC *f,int i)
{

    if (i<=entete(f,1) && i!=0) //Si le bloc i existe
    {   Tbloc buf;
       lireDir(f,i,&buf);       //On lit le bloc
        printf("Bloc %d : %s\n",i,buf.tab); // On l'affiche

    }
    else
    {
        printf("\nle bloc %d n'existe pas !\n",i);
    }



}
/***************************************************************************/
/*----------------Fonction Affiche fichier----------------------------------*/
//Role:Affiche le fichier "nom" bloc par bloc
/***************************************************************************/
void affiche_fichier(char nom[30])
{
    TOVC *f;
    f=ouvrir(nom,'A');
    if (f!=NULL)  //Si le fichier existe deja
    {if (entete(f,1)==0)
    {
        printf("Ce fichier est vide!\n");

    }
    else
    {
        int i=1;
        while (i<=entete(f,1)) //On parcourt le fichier bloc par bloc
        {
            affiche_bloc(f,i);   //On affiche le bloc
            i++;
        }
    }

    }
    else
    {
        printf("Erreur lors de l'ouverture du fichier veuillez reessayer !\n");
    }

}
/***************************************************************************/
/*----------------------------RECHERCHE-------------------------------------*/
//Role:Cherche l'article et donne sa position Si on ne trouve le pas  la fonction retourne le i,j dans la position ou on devrait l'ins�rer la prochaine fois
/***************************************************************************/
void recherche(char nom[30],char cle[4],int *trouv,int *i,int *j,int *cost,int *efface,int *decal)
{
    TOVC *f;
    int cpt_rec;
    char taille[3]="";char eff[1]="";char c[4]="";
    int cpt_lect=0,r;
    Tbloc buf;
    f=ouvrir(nom,'A');
    if (f!=NULL)
    {
    (*i)=1;(*j)=0;
    int cle_int=atoi(cle),c_int,tai;
    int stop=0;
    (*trouv)=0;
    (*efface)=0;
    (*decal)=0;
    lireDir(f,(*i),&buf);cpt_lect++;   //On lit le premier buffer
    while ((*trouv)==0 && stop==0 )
           {

               strcpy(taille,recuperer(f,3,i,j,&cpt_rec)); //On recupere la taille le champ effac�e et la cl�
               tai=atoi(taille);
               cpt_lect=cpt_lect+cpt_rec;
               strcpy(eff,recuperer(f,1,i,j,&cpt_rec));
               r=atoi(eff);
               cpt_lect=cpt_lect+cpt_rec;
               strcpy(c,recuperer(f,4,i,j,&cpt_rec));
               c_int=atoi(c);
              cpt_lect=cpt_lect+cpt_rec;


               if (c_int==cle_int)
               {
                   if (r==0  )       //Si on trouve la cl� on verrifie si la donn�e n'est pas effac�e
                   {
                       (*trouv)=1;
                   }
                   else
                   {
                       stop=1;
                       (*efface)=1;    //Si elle est effac�e on retourne ce bool�en pour l'utuliser dans l'insertion
                   }
                    (*j)=(*j)-8;         //On repositionne le j au debut de l'article
                    if ((*j)<0)
                    {
                        (*i)--;
                        (*j)=(*j)+taille_bloc;
                        if ((*i)<0)
                        {
                            (*i)=1;
                            (*j)=0;
                        }
                    }

                   }
                   else  // Si ! trouv
                   {
                       if (c_int>cle_int)  //Si on arrive a une cl� sup�rieure � celle qu'on cherche on s'arrete parce qu'elle devrait etre ins�r�e ici plus tard
                       {
                           stop=1;
                           (*decal)=1;
                           (*j)=(*j)-8;    //On repositionne le j au debut de l'article
                          if ((*j)<0)
                        {
                           (*i)--;
                           (*j)=(*j)+taille_bloc;
                           if ((*i)<0)
                          {
                            (*i)=1;
                            (*j)=0;
                          }

                       }
                   }
                   else
                   { (*j)=(*j)+tai-4;  //On avance vers le prochain article
                    if ((*j)>=taille_bloc)
                    {
                        (*i)++;
                        (*j)=(*j)-taille_bloc;
                        if ((*i)>entete(f,1))   //On arrive a la fin du fichier, i et j devrait etre positionner au debut d'un nouveau bloc
                        {
                            stop=1;
                            (*j)=0;
                        }
                        else
                        {
                            lireDir(f,(*i),&buf);cpt_lect++;
                        }
                    }
                     if (stop==0 && (*i)==entete(f,1) && (*j)==entete(f,5)) //On arrive a la fin du fichier mais le dernier bloc n'est pas completement remplis
                     {
                         stop=1;                                             //On s'arrete , i et j sont positionner a la derniere position libre
                     }
                   }

               }
           }
           (*cost)=cpt_lect;
    }
    else
    {
        printf("\nErreur lors de l'ouverture du fichier !!\n");
    }

}
/*********************************************************************************************/
/*-----------------------------Affiche entete------------------------------------------------*/
/*********************************************************************************************/
void Afficher_Entete(TOVC *f)
  {
      int i;
      for (i=1;i<6;i++)
      {
          switch(i)
          {
          case 1:
            printf("\nLe nombre de blocs est : %d \n",entete(f,1));
            break;
            case 2:
            printf("\nLe nombre d'articles est : %d \n",entete(f,2));
            break;
           case 3:
            printf("\nLe nombre de caract�res supprim�s est :  %d \n",entete(f,3));
            break;
             case 4:
            printf("\nLe nombre de caract�res ins�r�s est :  %d \n",entete(f,4));
            break;
             case 5:
            printf("\nL'indice de la derni�re position libre du dernier bloc est :  %d \n",entete(f,5));
            break;

          }

      }
  }

/***************************************************************************************/
/*--------------------------------Reorganisation---------------------------------------*/
//Role:ecrire les articles non supprim�s dans un nouveau fichier
/***************************************************************************************/

void reorganisation(char nom1[30] , char nom2[30])
{
        TOVC *f1,*f2;
    f1 = ouvrir(nom1,'a');
    int cpt_l,cpt_e;
    if (f1!=NULL)
    {

    f2 = ouvrir(nom2 ,'n');
    int j1=0,k=0,i1=1,b=alloc_bloc(f2),i2=b; // les initialisations pour parcourire les deux blocs des deux fichiers
    char taille[3],eff[1],donnee[taille_bloc-4];
    int tai; //taille convertit en entier
    int arret=0; // des conditions d'arret
    int cpt_ins=0,cpt_article=0;   // pour garder le nombre des car inseres et le nombres d'articles pour la mise � jour de l'entete
    Tbloc buf1,buf2;
    lireDir(f1,i1,&buf1);
    char ch2[taille_bloc]="";
     int test;
       while ( arret == 0)
       {
           strcpy(taille,recuperer(f1,3,&i1,&j1,&cpt_l));  // recuperer la taille
          tai = atoi(taille);
          strcpy(eff,recuperer(f1,1,&i1,&j1,&cpt_l));test=atoi(eff); // recuperer le champs eff
          strcpy(donnee,recuperer(f1,tai,&i1,&j1,&cpt_l)); // recuperer la donnee

            b=i2; // on sauvegarde la variable pour l'utiliser plus tard car le langage C nous change b sans aucune reaison !
          if(test == 0)
            {    // on �crit la chaine dans le fichier organis�

              prepare_article(ch2,donnee);
              ecrire_ch(f2,strlen(ch2),&b,&k,ch2,&cpt_l,&cpt_e);
              i2=b;
              cpt_ins= cpt_ins + strlen(ch2);
              strcpy(ch2,"");
              cpt_article++;
            }

       if ( i1 == entete(f1,1)   &&  j1 == entete(f1,5))
       {
           arret = 1; //condition d'arret lorsque tout les articles sont test�s
       }
       }
       if (k==0)   // pour ecrire le dernier bloc non plein si il existe
    {
        (b)--;
        aff_entete(f2,1,b);
    }
    //mise � jour de l'entete
     aff_entete(f2,2,cpt_article);
     aff_entete(f2,4,cpt_ins);
     aff_entete(f2,3,0);
     aff_entete(f2,5,k);
     fermer(f2);
    }
    else
    {
        printf("\nErreur lors de l'ouverture du fichier !!");
    }
}
/*******************************************************************************************/
/*------------------------------Supression-------------------------------------------------*/
//Role:Effectue une suppression logique
/*******************************************************************************************/
void Supprimer(char nom[30],char Cle[4],int *cost_lec,int *cost_ecr)
{
    TOVC *f;
    Tbloc buf;
    f=ouvrir(nom,'a');
    int cpt_l,cpt_e;
    int cmp_l=0,cmp_e=0;
    if (f!=NULL)
   {

    int trouv,i,j,efface,cost,decal;
    recherche(nom,Cle,&trouv,&i,&j,&cost,&efface,&decal); // rechercher la position ou se trouve la cle qu'on veut supprimer
    cmp_l=cmp_l+cost;
    if ( trouv == 0) // dans le cas ou elle n'existe pas
    {
        printf("\n Aucune supression � effectuer  ! ! ! \n");
    }
    else
    {    // dans le cas ou elle existe
         char taille[3]="";
         strcpy(taille,recuperer(f,3,&i,&j,&cpt_l)); // recuperer la taille
         int tai=atoi(taille);
          cmp_l=cmp_l+cpt_l;
         aff_entete(f,3,entete(f,3)+tai+4); //incrementer le nombre de caracteres supprimes

        lireDir(f,i,&buf);
        cmp_l++;

        buf.tab[j]='1'; // changer le champ eff � 1
        ecrireDir(f,i,&buf);
        cmp_e++;



    }
    (*cost_lec)=cmp_l;
    (*cost_ecr)=cmp_e;
    fermer(f);


   }
   else
   {
       printf("\nErreur lors de l'ouverture du fichier !\n");
   }

}
/*******************************************************************************************/
/*------------------------INSERTION--------------------------------------------------------*/
/*******************************************************************************************/

  void insertion(char nom[30], char chaine[taille_bloc],int c,int *cost_lec,int *cost_ecr)
  {
    TOVC *f;
    Tbloc buff,buf2,buf;
    f=ouvrir(nom,'a');
    int i,j,longeur;
    int cmp_l=0,cmp_e=0;
    int cpt_l,cpt_e;
    int trouv,effacee,Cost,decal;
    longeur = strlen(chaine);
    // on aura besoin de la longeur pour savoir combien de caract�res on va inserer
    if ( f == NULL)
    {
         // premier cas ou le fichier est vide alors la premiere insertion effectuee
        f= ouvrir(nom,'n');
        i =alloc_bloc(f);
        j=0;
        ecrire_ch(f,longeur,&i,&j,chaine,&cpt_l,&cpt_e);
        cmp_l=cmp_l+cpt_l;
        cmp_e=cmp_e+cpt_e;

        aff_entete(f,4,longeur);
        aff_entete(f,5,j);
        aff_entete(f,2,1);
        // cette verification dans le cas ou on a allouer un nouveau bloc vide dans notre fichier alors on va l'iniber
         if (j==0)
               {
                (i)--;
                aff_entete(f,1,(i));
               }




    }
    else
    {
        char cle[4]="";
        turn_to_string(cle,c,4);
        recherche(nom,cle,&trouv,&i,&j,&Cost,&effacee,&decal);        // on recherche la valeur avec la position ou on doit inserer si c est le cas
        cmp_l=cmp_l+Cost;
        if ( trouv == 1 )     // ce cas veut dire on va pas inserer les doublons

        {
            printf("\n Aucune insertion a effectuer ! ! ! \n");

        }
        else
        {
           if ( effacee == 1)          // ce cas veut dire si la valeur existe mais elle est supprimee logiquement on va remettre l'indice eff � 0

           {

            lireDir(f,i,&buf);
            cmp_l++;
             j= j+3;
                if ( j >= taille_bloc)
                {
                    j=0;
                    i++;
                    lireDir(f,i,&buf);
                    cmp_l++;
                }
             buf.tab[j]='0';
             ecrireDir(f,i,&buf);
             cmp_e++;
             aff_entete(f,3,entete(f,3)-longeur);

           }
           else
           {

                  if ( (i == entete(f,1)) && (j == entete(f,5)) && (decal==0))        // le cas ou on va inserer � la fin du fichier a la derniere position

                  {
                      ecrire_ch(f,longeur,&i,&j,chaine,&cpt_l,&cpt_e);
                      cmp_l=cmp_l+cpt_l;
                      cmp_e=cmp_e+cpt_e;
                      aff_entete(f,5,j);
                      aff_entete(f,4,entete(f,4)+longeur);
                       if (j==0)
                    {
                  (i)--;
                aff_entete(f,1,(i));
                     }

                  }
                  else
                  {
                      if ( (i > entete(f,1)) && (j ==0) )  // c est le cas ou on va allouer un nouveau bloc
                      {

                          i= alloc_bloc(f);
                          ecrire_ch(f,longeur,&i,&j,chaine,&cpt_l,&cpt_e);
                          cmp_l=cmp_l+cpt_l;
                         cmp_e=cmp_e+cpt_e;
                          aff_entete(f,5,j);
                          aff_entete(f,4,entete(f,4)+longeur);
                           if ( j == 0)
                           {
                               (i)--;
                               aff_entete(f,1,i);
                           }

                      }
                      else
                      {
                               // la on va effectuer des decalages pour ecrire la chaine au milieu du fichier
                           strcpy(buf.tab,"");
                         int stop=0,cas_special=0;
                         // cas_special sert � voir si on va allouer un bloc ou non pour le decalage de la derniere postion avec longeur positions
                         int b=entete(f,1),k=entete(f,5);
                         int s,s2,ind;
                         f=ouvrir(nom,'a');

                         // s --> pour savoir la position ou on va decaler notre caractere
                         // s2 --> pour savoir le bloc ou on va decaler notre caractere
                          // ind --> pour garder la premiere valeur de s car �a sera la derniere position libre du fichier mis � jour
                          // k --> pour avoir l'indice du caractere qu'on va decaler ver la position s du bloc s2
                          // b --> pour avoir l'indice du bloc du caractere qu'on va decaler vers la position s du bloc s2

                           k--;
                          if ( k <0)
                           {
                               k =taille_bloc-1;
                               b--;
                               if ( b <= 0)
                               {
                                   b=1;
                               }
                           }

                        while ( stop == 0)
                        {
                            if ( cas_special == 0)
                            {
                                lireDir(f,b,&buf);
                                cmp_l++;
                               s = longeur + k;
                               s2 = b;   ind=s;
                                 if ( s >= taille_bloc)
                                 {
                                     // on va allouer un bloc car le dernier bloc est plein
                                     s = s-taille_bloc;  ind=s;
                                     s2 = alloc_bloc(f);
                                     strcpy(buf2.tab,"");
                                     buf2.tab[s]=buf.tab[k];
                                     ecrireDir(f,s2,&buf2);
                                     cmp_e++;
                                 }
                                 else
                                 {
                                     // on va juste decaler dans le dernier bloc
                                     buf.tab[s]= buf.tab[k];
                                     strcpy(buf2.tab,buf.tab);
                                     ecrireDir(f,b,&buf);
                                     cmp_e++;
                                      strcpy(buf.tab,"");

                                 }
                                 k--;
                                 if( k<0)
                                 {
                                     k=taille_bloc-1;
                                     b--;
                                      if ( b <= 0)
                               {
                                   b=1;
                               }
                                     lireDir(f,b,&buf);
                                     cmp_l++;
                                 }
                                 s--;
                                 if (s<0)
                                 {
                                     s=taille_bloc-1;
                                     s2--;
                                       if ( s2 <= 0)
                               {
                                   s2=1;
                               }
                                     lireDir(f,s2,&buf2);
                                     cmp_l++;
                                 }
                                 cas_special=1;
                                 // on a mis le cas_special � 1 --->>> ce cas se realise qu'une seule fois

                            }
                            else
                            {
                                buf2.tab[s]=buf.tab[k];
                                if ( (b == i)&&(j == k))
                                {
                                    ecrireDir(f,s2,&buf2);
                                    cmp_e++;
                                    strcpy(buf2.tab,"");
                                    strcpy(buf.tab,"");
                                    stop=1;
                                }
                                else
                                {

                                 k--;
                                 if( k<0)
                                 {
                                     k=taille_bloc-1;
                                     b--;
                                      if ( b <= 0)
                               {
                                   b=1;
                               }
                                     strcpy(buf.tab,"");
                                     lireDir(f,b,&buf);
                                     cmp_l++;
                                 }
                                 s--;
                                 if (s<0)
                                 {
                                     s=taille_bloc-1;
                                     ecrireDir(f,s2,&buf2);
                                     cmp_e++;
                                     s2--;
                                        if ( s2 <= 0)
                               {
                                   s2=1;
                               }
                                     lireDir(f,s2,&buf2);
                                     cmp_l++;
                                 }

                                }


                            }


                        }
                        // on a alors effectuer les decalages
                        // alors on va ecraser le contenu � partir de i,j avec une chaine de longeur : longeur
                            strcpy(buff.tab,"");
                           lireDir(f,i,&buff);
                           cmp_l++;
                           int cpt=0;
                           while ( cpt < longeur)
                           {
                               buff.tab[j]=chaine[cpt];
                               cpt++;
                               j++;
                               if ( j >= taille_bloc)
                               {
                                   j=0;
                                   ecrireDir(f,i,&buff);
                                   cmp_e++;
                                   i++;
                                   lireDir(f,i,&buff);
                                   cmp_l++;
                               }

                           }
                            if (j!=0)
                         {
                          ecrireDir(f,i,&buff);
                          cmp_e++;
                         }


                            aff_entete(f,4,longeur+entete(f,4));
                            ind++; // pour recuperer l'indice de la nouvelle derniere position
                              if ( ind >= taille_bloc)
                              {
                                  ind =0;
                              }
                              aff_entete(f,5,ind);



                      }


                  }
                aff_entete(f,2,entete(f,2)+1);


           }

        }

    }

    (*cost_lec)=cmp_l;
    (*cost_ecr)=cmp_e;
     fermer(f);

  }










