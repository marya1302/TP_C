#define taille_bloc 50
//****************Declaration des structures************************//
typedef struct Tbloc
    {
        char tab[taille_bloc];
    } Tbloc;
    typedef struct Entete
    {
        int NbBloc;          //Nombre de Blocs dans le fichier
        int NbArticle;       //Nombre d'articles dans le fichier
        int car_supp;        //Nombre de caract�res supprim�s
        int car_ins;         //Nombre de caract�res ins�r�s
        int der_pos;        // derni�re position libre dans le dernier bloc
    } Entete;
    typedef struct TOVC
    {
        FILE *fichier;           //Le type TOVC contien le fichier et l'enregistrement de son entete
        Entete entete;
    } TOVC;


     /*----------Prototypes des fonctions----------*/
    TOVC *ouvrir(char chemin[30],char mode);
    void fermer(TOVC *f);
    void lireDir(TOVC *f,int N_Bloc,Tbloc *buffer);
    void ecrireDir(TOVC *f,int N_Bloc,Tbloc *buffer);
    int entete(TOVC *f,int i);
    void aff_entete(TOVC *f, int i, int val);
    int alloc_bloc(TOVC *f);

    /*--------------------------------------------*/


