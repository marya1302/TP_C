 #define taille_bloc 50
//****************Declaration des structures************************
typedef struct Tbloc
    {
        char tab[taille_bloc];
    } Tbloc;
    typedef struct Entete
    {
        int NbBloc;          //Nombre de Blocs dans le fichier
        int NbArticle;       //Nombre d'articles dans le fichier
        int car_supp;        //Nombre de caract�res supprim�s
        int car_ins;         //Nombre de caract�res ins�r�s
        int der_pos;        // derni�re position libre dans le dernier bloc
    } Entete;
    typedef struct TOVC
    {
        FILE *fichier;           //Le type TOVC contien le fichier et l'enregistrement de son entete
        Entete entete;
    } TOVC;

    /*----------Prototypes des fonctions----------*/
    void ecrire_ch(TOVC *f,int n,int *i,int *j,char ch[taille_bloc],int *cost_lec,int *cost_ecr);
    void turn_to_string(char chaine[], int n, int longueur);
    void prepare_article(char chaine[],char donne[taille_bloc]);
    char *recuperer(TOVC *f,int n,int *i,int *j,int *cost);
    void affiche_bloc(TOVC *f,int i);
    void affiche_fichier(char nom[30]);
    void recherche(char nom[30],char cle[4],int *trouv,int *i,int *j,int *cost,int *eff,int *decal);
    void Afficher_Entete(TOVC *f);
    void reorganisation(char nom1[30] , char nom2[30]);
    void Supprimer(char nom[30],char Cle[4],int *cost_lec,int *cost_ecr);
    void insertion(char nom[30], char chaine[taille_bloc],int c,int *cost_lec,int *cost_ecr);

     /*--------------------------------------------*/
