#include <stdio.h>
#include <stdlib.h>
#include "model.h"
#include <string.h>

//**********************************************************************************************************************
/*--------------Fonction d'ouverture d'un fichier--------------*/
TOVC *ouvrir(char chemin[30],char mode)
{
    TOVC *f = malloc(sizeof(TOVC));
    char s[3];
    if((mode == 'A') || (mode == 'a')) strcpy(s,"rb+");  //On recup�re le mode d'ouverture dans s
    else if ((mode == 'N') || (mode == 'n')) strcpy(s,"wb+");
    else return 0;

    (f)->fichier =fopen(chemin,s);  //On ouvre le fichier

    if((f)->fichier == NULL)   return (NULL); //Si le fichier n'existe pas on retourne NULL

    if((mode == 'A') || (mode == 'a'))
    {
        fread(&((f)->entete), sizeof(Entete), 1, (f)->fichier); //On lit l'entete qui se trouve au debut du fichier
    }
    else if ((mode == 'N') || (mode == 'n'))
    {
        (f)->entete.NbBloc = 0;   //On initialise l'entete
        (f)->entete.NbArticle = 0;
        (f)->entete.car_supp= 0;
        (f)->entete.car_ins=0;
        (f)->entete.der_pos=0;

    }
    return f;
}
/*--------------------------------------------------------------*/

/*--------------Fonction de fermeture d'un fichier--------------*/
void fermer(TOVC *f)
{
    //Sauvegarde de l'ent�te
    rewind(f->fichier);
    fwrite(&(f->entete), sizeof(Entete), 1, f->fichier);
    fclose(f->fichier); //Fermiture du fichier


}
/*--------------------------------------------------------------*/

/*-----------------Fonction de lecture d'un bloc----------------*/
void lireDir(TOVC *f,int N_Bloc,Tbloc *buffer)
{
    if(N_Bloc <= (f->entete).NbBloc) //Si le bloc existe
    {
        fseek(f->fichier, sizeof(Entete) + (N_Bloc-1) * sizeof(Tbloc),SEEK_SET); //On avance vers le bloc i
        fread(buffer, 1, sizeof(Tbloc), f->fichier); //On lit le bloc dans buffer
    }
}
/*--------------------------------------------------------------*/

/*-----------------Fonction d'�criture d'un bloc----------------*/
void ecrireDir(TOVC *f,int N_Bloc,Tbloc *buffer)
{
    if(N_Bloc <= (f->entete).NbBloc)
    {
        fseek(f->fichier, sizeof(Entete) + (N_Bloc-1) * sizeof(Tbloc),SEEK_SET);  //On avance vers la position i ou on veut ecrire
        fwrite(buffer, 1, sizeof(Tbloc), f->fichier);
    }
}
/*--------------------------------------------------------------*/

/*----------------Fonction de lecture de l'ent�te---------------*/

int entete(TOVC *f,int i)
{   //On choisit la caract�ristique a retourner selon le i
    if(i == 1) return (f->entete).NbBloc;
    else if(i == 2) return (f->entete).NbArticle;
    else if(i == 3) return (f->entete).car_supp;
    else if(i == 4) return (f->entete).car_ins;
    else if(i == 5) return (f->entete).der_pos;


    else return -1; //Si elle n'existe pas on retourne -1
}
/*--------------------------------------------------------------*/


/*-------------Fonction de modification de l'ent�te-------------*/

void aff_entete(TOVC *f, int i, int val)
{   //On choisit la caract�ristique a modifier selon le i
    if(i == 1) (f->entete).NbBloc = val;
    else if(i == 2) (f->entete).NbArticle = val;
    else if(i == 3) (f->entete).car_supp = val;
    else if(i == 4) (f->entete).car_ins = val;
    else if(i == 5) (f->entete).der_pos = val;

}
/*--------------------------------------------------------------*/

/*--------------------L'allocation d'un bloc--------------------*/
int alloc_bloc(TOVC *f)
{
    aff_entete(f,1,entete(f,1)+1); //On alloe un nouveau bloc donc on modifie le nombre de blocs du fichier
    return entete(f,1); //On retourne la position de ce bloc
}
/***************************************************************************************************************/
