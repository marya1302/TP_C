#include <stdio.h>
#include <stdlib.h>
#include "fonctions.h"
#include <string.h>

int main()
{
 printf("************************TP TOVC********************************\n");
 printf("-------------------------Menu----------------------------------\n");
 printf("1--Afficher un fichier bloc par bloc\n");
 printf("2--Afficher un bloc\n");
 printf("3--Afficher l'entete d'un fichier\n");
 printf("4--Rechercher un article\n");
 printf("5--Supprimer logiquement un article\n");
 printf("6--Insertion\n");
 printf("7--Reorganisation manuelle\n");

 int o;

 TOVC *f;
 int i;
 int trouv,m,v,cost,eff,decal;
 char nom[30],nom2[30],c[4]="";
 int n,nombre,cpt=1,b,k,cl;
 char donnee[taille_bloc-4]="",ch2[taille_bloc]="";
int cpt_lect,cpt_ecrt;
int cmp_lect,cmp_ecr;

 int continu=1;
 while (continu==1)
 {
    printf("\nChoisissez l'operation a executer : ");
    scanf("%d",&o);
     printf("\n");

 switch (o)
 { case 1 :
   printf("Donner le chemin vers le fichier que vous voulez afficher :");
   scanf("%s",nom);
   affiche_fichier(nom);
     break;

    case 2 :
  printf("\nDonner le chemin vers le fichier que vous voulez afficher : ");
   scanf("%s",nom);
   printf("\nDonner le numero du bloc a afficher : ");
   scanf("%d",&i);
   f=ouvrir(nom,'A');
   affiche_bloc(f,i);

    break;

    case 3 :
        printf("\nDonner le chemin vers votre fichier : ");
        scanf("%s",nom);
        f=ouvrir(nom,'A');
        Afficher_Entete(f);
        break;

    case 4 :
        printf("\nDonner le chemin vers votre fichier : ");
        scanf("%s",nom);
        printf("\nDonner la cle que vous cherchez: ");
        scanf("%d",&i);
        turn_to_string(c,i,4);
        recherche(nom,c,&trouv,&m,&v,&cost,&eff,&decal);
        printf("\nTrouv= %d || Bloc= %d || Position= %d \n",trouv,m,v);
        printf("\nCout de l'operation : Nombre de lectures= %d  || Nombre d'ecritures= 0\n",cost);
        break;
    case 5 :
        printf("\nDonner le chemin vers votre fichier : ");
        scanf("%s",nom);
        printf("\nDonner la cle a supprimer :");
        scanf("%d",&i);
        turn_to_string(c,i,4);
        Supprimer(nom,c,&cpt_lect,&cpt_ecrt);
        printf("\nSuppression reussie ! ! ! \n");
        printf("\nCout de l'operation : Nombre de lectures= %d  || Nombre d'ecritures= %d\n",cpt_lect,cpt_ecrt);
        f=ouvrir(nom,'A');
        if ((2*entete(f,3)> entete(f,4)))
        {

             printf("\nUne reorganisation doit etre effectuer donner le nom vers le nouveau fichier : ");
            scanf("%s",nom2);
            reorganisation(nom,nom2);
        }
        break;

    case 6 :
   printf("\nDonner le chemin vers votre fichier : ");
  scanf("%s",nom);
   printf("\nEntrer le nombre de donnee � inserer : ");
   scanf("%d",&nombre);
   n=nombre; b=1; k=0;
      cpt=1;cmp_ecr=0;cmp_lect=0;

    // Le C change sans aucune raison la valeur de nombre alors on l'a sauvegarder dans n
    while( cpt <= n)
   {

   printf("\n Entrer la donnee %d que vous voulez inserer : ",cpt);
   scanf("%s",donnee);
    while ( b<=4)
    {
        c[k]=donnee[k];
        k++;
        b++;
    }
  c[4]='\0';
  cl=atoi(c);
   strcpy(ch2,"");
  prepare_article(ch2,donnee);
  insertion(nom,ch2,cl,&cpt_lect,&cpt_ecrt);
  cmp_lect=cmp_lect+cpt_lect;
  cmp_ecr=cmp_ecr+cpt_ecrt;

  b=1;
  k=0;
   cpt++;
   }
   printf("\nInsertion r�ussie !!!\n");
   printf("\nCout de l'operation : Nombre de lectures= %d  || Nombre d'ecritures= %d\n",cmp_lect,cmp_ecr);

        break;

    case 7 :
        printf("\nDonner le chemin vers votre fichier : ");
        scanf("%s",nom);
        printf("\nDonner le nom vers le nouveau fichier : ");
        scanf("%s",nom2);
        reorganisation(nom,nom2);

        break;

    default :
        printf("\nCette option n'existe pas !!!\n");
        break;

 }
 printf("\nVoulez vous continuer ?\n");
 printf("1--Oui  || 2--Non\n");
 int cont;
 scanf("%d",&cont);
 switch (cont)
 {
   case 1 :
       continu=1;
      break;
   case 2 :
       continu=0;
    break;
   default :
    break;
 }
 }
}
